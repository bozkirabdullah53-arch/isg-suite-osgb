from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from uuid import uuid4
from zoneinfo import ZoneInfo
import base64
import logging
import re

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from app.api.company_access import ensure_company_access, find_professional_for_user
from app.api.deps import get_current_user, require_roles
from app.core.config import settings
from app.core.database import get_db
from app.models.entities import (AssignmentStatus, ChemicalProduct, Company, CrmLead, FinanceTransaction,
                                 IsgProfessional, OsgbOrganization, ServiceContract, ServiceVisit, User,
                                 UserRole, VisitStatus, WorkplaceAssignment)
from app.schemas.operations import (FinanceCreate, FinanceResponse, FinanceUpdate, LeadCreate, LeadResponse, LeadUpdate,
                                    VisitCheckStamp, VisitCreate, VisitGpsStamp, VisitPlanCreate, VisitResponse, VisitUpdate)
from app.services.crm_convert import convert_lead_to_contract
from app.services.finance_accrual import accrue_month_for_osgb
from app.services.visit_calendar import build_visit_calendar
from app.services.module_kpis import build_module_kpis
from app.services.site_verify import (
    codes_match,
    consume_ephemeral_token,
    ensure_company_site_verify_code,
    resolve_company_from_site_code,
    validate_ephemeral_token,
)
from app.services.upload_gateway import persist_relative
from app.services.upload_security import assert_safe_upload

router = APIRouter(prefix="/operations", tags=["OSGB Operasyonları"])
logger = logging.getLogger(__name__)
ADMIN = (UserRole.GLOBAL_ADMIN, UserRole.COMPANY_ADMIN)
VISIT_ROLES = (
    UserRole.GLOBAL_ADMIN,
    UserRole.COMPANY_ADMIN,
    UserRole.SAFETY_SPECIALIST,
    UserRole.WORKPLACE_PHYSICIAN,
    UserRole.OTHER_HEALTH_PERSONNEL,
)
FIELD_VISIT_ROLES = (
    UserRole.SAFETY_SPECIALIST,
    UserRole.WORKPLACE_PHYSICIAN,
    UserRole.OTHER_HEALTH_PERSONNEL,
)
ALLOWED_NOTEBOOK = {".pdf", ".jpg", ".jpeg", ".png"}
_FIELD_ROLES = set(FIELD_VISIT_ROLES)


def _apply_gps_stamp(obj: ServiceVisit, lat: float | None, lng: float | None, accuracy: float | None = None):
    if lat is None or lng is None:
        return
    if not (-90 <= lat <= 90) or not (-180 <= lng <= 180):
        raise HTTPException(422, "GPS koordinatları geçersiz.")
    obj.gps_lat = float(lat)
    obj.gps_lng = float(lng)
    obj.gps_accuracy_m = float(accuracy) if accuracy is not None else None
    obj.gps_captured_at = datetime.utcnow()


def _apply_site_verify(db: Session, obj: ServiceVisit, company: Company | None, raw_code: str | None):
    """Ziyaret tamamlama QR — kalıcı veya geçici; boş gönderim yok (P0-05)."""
    if not company:
        raise HTTPException(400, "İşyeri bulunamadı.")
    # Eski kayıtlarda kod yoksa üret; QR'siz tamamlamaya izin verme
    ensure_company_site_verify_code(db, company)
    if not raw_code or not str(raw_code).strip():
        raise HTTPException(422, "İşyeri QR doğrulama kodu gerekli.")
    if codes_match(company.site_verify_code, raw_code):
        obj.site_verified_at = datetime.utcnow()
        return
    if consume_ephemeral_token(db, company.id, raw_code):
        obj.site_verified_at = datetime.utcnow()
        return
    raise HTTPException(400, "QR kodu bu işyeri ile eşleşmiyor veya süresi dolmuş.")


def _verify_site_presence(db: Session, company: Company, raw_code: str | None):
    """Kiosk giriş/çıkış — ephemeral consume edilmez (aynı TTL içinde yeniden kullanılır)."""
    ensure_company_site_verify_code(db, company)
    if not raw_code or not str(raw_code).strip():
        raise HTTPException(422, "İşyeri QR doğrulama kodu gerekli.")
    if codes_match(company.site_verify_code, raw_code):
        return
    if validate_ephemeral_token(db, company.id, raw_code):
        return
    raise HTTPException(400, "QR kodu bu işyeri ile eşleşmiyor veya süresi dolmuş.")


def _require_field_assignment(db: Session, user: User, company_id: int) -> IsgProfessional:
    pro = find_professional_for_user(db, user)
    if not pro:
        raise HTTPException(
            400,
            "Profesyonel kaydınız bulunamadı. Kullanıcı e-postanızın İSG Profesyonelleri kaydıyla aynı olduğundan emin olun.",
        )
    assign = db.scalar(
        select(WorkplaceAssignment).where(
            WorkplaceAssignment.professional_id == pro.id,
            WorkplaceAssignment.company_id == company_id,
            WorkplaceAssignment.status == AssignmentStatus.ACTIVE,
        ).order_by(WorkplaceAssignment.id).limit(1)
    )
    if not assign:
        raise HTTPException(403, "Bu işyerine aktif görevlendirmeniz yok.")
    return pro


def _open_checkin_visit(db: Session, professional_id: int, company_id: int) -> ServiceVisit | None:
    return db.scalar(
        select(ServiceVisit).where(
            ServiceVisit.professional_id == professional_id,
            ServiceVisit.company_id == company_id,
            ServiceVisit.checked_in_at.is_not(None),
            ServiceVisit.checked_out_at.is_(None),
            ServiceVisit.status != VisitStatus.CANCELLED,
        ).order_by(ServiceVisit.id.desc()).limit(1)
    )


def _hhmm(dt: datetime) -> str:
    """Saat dilimi: Europe/Istanbul (naive datetime UTC kabul edilir)."""
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(ZoneInfo("Europe/Istanbul")).strftime("%H:%M")


def _today_tr() -> date:
    return datetime.now(timezone.utc).astimezone(ZoneInfo("Europe/Istanbul")).date()


_DATA_URL_RE = re.compile(r"^data:image/(png|jpeg|jpg);base64,(.+)$", re.IGNORECASE | re.DOTALL)


def _apply_signature(obj: ServiceVisit, data_url: str | None):
    if not data_url or not str(data_url).strip():
        return
    m = _DATA_URL_RE.match(str(data_url).strip())
    if not m:
        raise HTTPException(422, "İmza formatı geçersiz (PNG/JPEG data URL beklenir).")
    ext = ".png" if m.group(1).lower() == "png" else ".jpg"
    try:
        raw = base64.b64decode(m.group(2), validate=True)
    except Exception as exc:
        raise HTTPException(422, "İmza verisi çözülemedi.") from exc
    if len(raw) < 64:
        raise HTTPException(422, "İmza boş görünüyor.")
    if len(raw) > 350_000:
        raise HTTPException(413, "İmza dosyası çok büyük.")
    if obj.signature_storage_path:
        old = (_upload_root() / obj.signature_storage_path).resolve()
        if _upload_root() in old.parents and old.exists():
            try:
                old.unlink()
            except OSError:
                pass
    rel = f"{obj.osgb_id}/visits/{obj.id}_sig_{uuid4().hex[:10]}{ext}"
    if settings.upload_gateway_enabled:
        persist_relative(raw, relative_path=rel, original_name=f"imza{ext}", max_bytes=350_000)
    else:
        assert_safe_upload(raw, ext, f"imza{ext}")
        target = _upload_root() / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
    obj.signature_file_name = f"imza{ext}"
    obj.signature_storage_path = rel.replace("\\", "/")
    obj.signature_captured_at = datetime.utcnow()


def scope(user: User, osgb_id: int):
    """OSGB kapsamı. Saha rolleri (uzman/hekim/DSP) işyeri görevlendirmesi ile doğrulanır."""
    if user.role == UserRole.GLOBAL_ADMIN:
        return
    if user.role in _FIELD_ROLES:
        return
    if user.osgb_id != osgb_id:
        raise HTTPException(403, "Bu OSGB verisine erişim yetkiniz yok.")


def active_osgb(user: User, requested: int | None = None, db: Session | None = None) -> int:
    if user.role == UserRole.GLOBAL_ADMIN:
        # GA: query param > kullanıcıya bağlı OSGB > ilk aktif OSGB
        oid = requested or user.osgb_id
        if not oid and db is not None:
            row = db.scalar(
                select(OsgbOrganization)
                .where(OsgbOrganization.is_active.is_(True))
                .order_by(OsgbOrganization.id)
                .limit(1)
            )
            oid = row.id if row else None
    elif user.role in _FIELD_ROLES:
        oid = user.osgb_id
        if not oid and db is not None:
            pro = find_professional_for_user(db, user)
            if pro:
                oid = pro.osgb_id
        if not oid:
            oid = requested
    else:
        oid = user.osgb_id
    if not oid:
        raise HTTPException(400, "Kullanıcıya bağlı bir OSGB bulunamadı.")
    scope(user, oid)
    return oid


def _upload_root() -> Path:
    root = Path(settings.upload_dir).resolve()
    root.mkdir(parents=True, exist_ok=True)
    return root


def _resolve_visit_professional(db: Session, user: User, payload: VisitCreate) -> IsgProfessional:
    if user.role in _FIELD_ROLES:
        pro = find_professional_for_user(db, user)
        if not pro:
            raise HTTPException(
                400,
                "Profesyonel kaydınız bulunamadı. Kullanıcı e-postanızın İSG Profesyonelleri kaydıyla aynı olduğundan emin olun.",
            )
        return pro
    if payload.professional_id:
        professional = db.get(IsgProfessional, payload.professional_id)
        if not professional or professional.osgb_id != payload.osgb_id:
            raise HTTPException(400, "Profesyonel OSGB ile eşleşmiyor.")
        return professional
    pro = find_professional_for_user(db, user)
    if pro:
        return pro
    assign = db.scalar(
        select(WorkplaceAssignment).where(
            WorkplaceAssignment.company_id == payload.company_id,
            WorkplaceAssignment.osgb_id == payload.osgb_id,
            WorkplaceAssignment.status == AssignmentStatus.ACTIVE,
        ).order_by(WorkplaceAssignment.id).limit(1)
    )
    if assign:
        professional = db.get(IsgProfessional, assign.professional_id)
        if professional:
            return professional
    raise HTTPException(400, "Bu işyerinde aktif görevlendirme yok; profesyonel belirlenemedi.")


def _get_visit(db: Session, visit_id: int, user: User) -> ServiceVisit:
    obj = db.get(ServiceVisit, visit_id)
    if not obj:
        raise HTTPException(404, "Ziyaret bulunamadı.")
    # EİSA, kendi OSGB yöneticisi veya ziyareti yapan saha personeli
    if user.role == UserRole.GLOBAL_ADMIN:
        return obj
    if user.role == UserRole.COMPANY_ADMIN:
        if user.osgb_id and obj.osgb_id == user.osgb_id:
            return obj
        raise HTTPException(403, "Bu ziyarete erişim yetkiniz yok.")
    if user.role in _FIELD_ROLES:
        pro = find_professional_for_user(db, user)
        if not pro or obj.professional_id != pro.id:
            raise HTTPException(403, "Bu ziyarete erişim yetkiniz yok.")
        return obj
    raise HTTPException(403, "Bu ziyarete erişim yetkiniz yok.")

@router.get("/dashboard")
def osgb_dashboard(osgb_id: int | None = None, db: Session = Depends(get_db), user: User = Depends(require_roles(*ADMIN))):
    oid = active_osgb(user, osgb_id, db)
    today = date.today()
    soon = today + timedelta(days=30)

    def count(model, *where):
        return db.scalar(select(func.count()).select_from(model).where(*where)) or 0

    workplaces = count(Company, Company.osgb_id == oid, Company.is_active == True)

    pros = list(
        db.scalars(
            select(IsgProfessional).where(
                IsgProfessional.osgb_id == oid,
                IsgProfessional.is_active == True,
            ).order_by(IsgProfessional.full_name)
        ).all()
    )
    assigned_pro_ids = set(
        db.scalars(
            select(WorkplaceAssignment.professional_id).where(
                WorkplaceAssignment.osgb_id == oid,
                WorkplaceAssignment.status == AssignmentStatus.ACTIVE,
            )
        ).all()
    )

    type_order = ("safety_specialist", "workplace_physician", "other_health_personnel")
    type_labels = {
        "safety_specialist": "İş Güvenliği Uzmanları",
        "workplace_physician": "İşyeri Hekimleri",
        "other_health_personnel": "Diğer Sağlık Personeli",
    }

    by_type: dict[str, dict] = {}
    unassigned_by_type: dict[str, dict] = {}
    for t in type_order:
        typed = [p for p in pros if p.professional_type.value == t]
        unassigned = [p for p in typed if p.id not in assigned_pro_ids]
        by_type[t] = {
            "type": t,
            "label": type_labels[t],
            "count": len(typed),
            "items": [
                {
                    "id": p.id,
                    "full_name": p.full_name,
                    "certificate_class": p.certificate_class,
                    "certificate_number": p.certificate_number,
                    "email": p.email,
                    "phone": p.phone,
                    "is_active": bool(p.is_active),
                    "assigned": p.id in assigned_pro_ids,
                }
                for p in typed
            ],
        }
        unassigned_by_type[t] = {
            "type": t,
            "label": type_labels[t],
            "count": len(unassigned),
            "items": [
                {
                    "id": p.id,
                    "full_name": p.full_name,
                    "certificate_class": p.certificate_class,
                    "certificate_number": p.certificate_number,
                    "email": p.email,
                    "phone": p.phone,
                }
                for p in unassigned
            ],
        }

    companies = {
        c.id: c.name
        for c in db.scalars(select(Company).where(Company.osgb_id == oid)).all()
    }
    expiring = list(
        db.scalars(
            select(ServiceContract).where(
                ServiceContract.osgb_id == oid,
                func.lower(ServiceContract.status) == "active",
                ServiceContract.end_date.is_not(None),
                ServiceContract.end_date.between(today, soon),
            ).order_by(ServiceContract.end_date)
        ).all()
    )
    upcoming_contracts = [
        {
            "id": c.id,
            "contract_number": c.contract_number,
            "company_id": c.company_id,
            "company_name": companies.get(c.company_id, f"#{c.company_id}"),
            "start_date": c.start_date.isoformat() if c.start_date else None,
            "end_date": c.end_date.isoformat() if c.end_date else None,
            "days_left": (c.end_date - today).days if c.end_date else None,
            "status": c.status,
            "monthly_fee": c.monthly_fee,
        }
        for c in expiring
    ]

    # Finans KPI: COUNT/SUM without row limit (alerts use totals only)
    income_pending = (
        FinanceTransaction.osgb_id == oid,
        FinanceTransaction.transaction_type == "income",
        FinanceTransaction.status == "pending",
        FinanceTransaction.due_date.is_not(None),
    )
    overdue_row = db.execute(
        select(
            func.count(),
            func.coalesce(func.sum(FinanceTransaction.amount), 0),
        ).where(
            *income_pending,
            FinanceTransaction.due_date < today,
        )
    ).one()
    due_soon_row = db.execute(
        select(
            func.count(),
            func.coalesce(func.sum(FinanceTransaction.amount), 0),
        ).where(
            *income_pending,
            FinanceTransaction.due_date.between(today, soon),
        )
    ).one()
    finance_overdue_count = int(overdue_row[0] or 0)
    finance_overdue_amount = int(overdue_row[1] or 0)
    finance_due_soon_count = int(due_soon_row[0] or 0)
    finance_due_soon_amount = int(due_soon_row[1] or 0)

    finance_alerts = []
    if finance_overdue_count:
        finance_alerts.append({
            "level": "critical",
            "text": f"{finance_overdue_count} vadesi gecmis tahakkuk ({finance_overdue_amount:,} TL)".replace(",", "."),
        })
    if finance_due_soon_count:
        finance_alerts.append({
            "level": "warning",
            "text": f"{finance_due_soon_count} tahakkuk 30 gun icinde vadeli ({finance_due_soon_amount:,} TL)".replace(",", "."),
        })

    contract_alerts = []
    if upcoming_contracts:
        contract_alerts.append({
            "level": "warning",
            "text": f"{len(upcoming_contracts)} aktif sozlesme 30 gun icinde bitiyor",
        })

    # 0.9.123 — SDS/PKD gözden geçirme (OSGB ana panel; saha siciline gitmez)
    company_ids = list(companies.keys())
    sds_overdue_count = 0
    sds_due_soon_count = 0
    if company_ids:
        sds_overdue_count = int(
            db.scalar(
                select(func.count()).select_from(ChemicalProduct).where(
                    ChemicalProduct.company_id.in_(company_ids),
                    ChemicalProduct.is_active.is_(True),
                    ChemicalProduct.next_review_date.is_not(None),
                    ChemicalProduct.next_review_date < today,
                )
            )
            or 0
        )
        sds_due_soon_count = int(
            db.scalar(
                select(func.count()).select_from(ChemicalProduct).where(
                    ChemicalProduct.company_id.in_(company_ids),
                    ChemicalProduct.is_active.is_(True),
                    ChemicalProduct.next_review_date.is_not(None),
                    ChemicalProduct.next_review_date.between(today, soon),
                )
            )
            or 0
        )

    sds_alerts = []
    if sds_overdue_count:
        sds_alerts.append({
            "level": "critical",
            "text": f"{sds_overdue_count} SDS / PKD gozden gecirme gecikmis",
        })
    if sds_due_soon_count:
        sds_alerts.append({
            "level": "warning",
            "text": f"{sds_due_soon_count} SDS / PKD gozden gecirme 30 gun icinde",
        })

    # QR / saha ziyaretleri — ServiceVisit (check-in/out + defter) profesyonel performansa da akar
    month_start = today.replace(day=1)
    if today.month == 12:
        month_end = date(today.year + 1, 1, 1) - timedelta(days=1)
    else:
        month_end = date(today.year, today.month + 1, 1) - timedelta(days=1)
    visit_month = list(
        db.scalars(
            select(ServiceVisit).where(
                ServiceVisit.osgb_id == oid,
                ServiceVisit.visit_date >= month_start,
                ServiceVisit.visit_date <= month_end,
            )
        ).all()
    )
    visits_this_month = len(visit_month)
    visits_qr_checkins = sum(1 for v in visit_month if getattr(v, "checked_in_at", None))
    visits_completed = sum(
        1
        for v in visit_month
        if (v.status.value if hasattr(v.status, "value") else str(v.status))
        in (VisitStatus.COMPLETED.value, "COMPLETED", "completed")
        or bool(getattr(v, "checked_out_at", None))
    )
    visits_open_on_site = sum(
        1
        for v in visit_month
        if getattr(v, "checked_in_at", None) and not getattr(v, "checked_out_at", None)
    )
    visits_minutes = sum(int(v.duration_minutes or 0) for v in visit_month if int(v.duration_minutes or 0) > 0)
    visit_alerts = []
    if visits_open_on_site:
        visit_alerts.append({
            "level": "warning",
            "text": f"{visits_open_on_site} profesyonel sahada (QR giris acik, cikis bekleniyor)",
        })

    return {
        "osgb_id": oid,
        "workplaces": workplaces,
        "professionals_by_type": by_type,
        "unassigned_by_type": unassigned_by_type,
        "unassigned_professionals": sum(v["count"] for v in unassigned_by_type.values()),
        "professionals": len(pros),
        "upcoming_contract_expiries": len(upcoming_contracts),
        "upcoming_contracts": upcoming_contracts,
        "period_days": 30,
        "finance_overdue_count": finance_overdue_count,
        "finance_overdue_amount": finance_overdue_amount,
        "finance_due_soon_count": finance_due_soon_count,
        "finance_due_soon_amount": finance_due_soon_amount,
        "finance_alerts": finance_alerts,
        "contract_alerts": contract_alerts,
        "sds_overdue_count": sds_overdue_count,
        "sds_due_soon_count": sds_due_soon_count,
        "sds_alerts": sds_alerts,
        "visits_this_month": visits_this_month,
        "visits_qr_checkins": visits_qr_checkins,
        "visits_completed": visits_completed,
        "visits_open_on_site": visits_open_on_site,
        "visits_minutes": visits_minutes,
        "visit_alerts": visit_alerts,
        "kpi_version": "dashboard-visits-qr-v4",
    }


@router.get("/module-kpis")
def module_kpis(
    osgb_id: int | None = None,
    db: Session = Depends(get_db),
    user: User = Depends(require_roles(*ADMIN)),
):
    """OSGB merkezi modül KPI — risk/DÖF, eğitim yenileme, sağlık periyodik takip."""
    oid = active_osgb(user, osgb_id, db)
    return build_module_kpis(db, oid)


@router.get("/visits/calendar")
def visits_calendar(
    month: str | None = None,
    osgb_id: int | None = None,
    professional_id: int | None = None,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Saha takvimi özeti — planlı/gecikmiş ziyaret ve eksik süre uyarıları.
    OSGB yöneticisi professional_id ile tek kişiye süzebilir.
    """
    pro = None
    if user.role in _FIELD_ROLES:
        pro = find_professional_for_user(db, user)
        if not pro:
            return build_visit_calendar(db, osgb_id=None, month=month)
        oid = pro.osgb_id
    elif user.role in (UserRole.GLOBAL_ADMIN, UserRole.COMPANY_ADMIN):
        oid = active_osgb(user, osgb_id, db)
    else:
        raise HTTPException(403, "Takvim görüntüleme yetkiniz yok.")
    data = build_visit_calendar(db, osgb_id=oid, month=month)

    # Saha personeli: yalnız kendi ziyaretleri
    # OSGB: isteğe bağlı professional_id filtresi
    filter_pid = None
    if pro:
        filter_pid = pro.id
    elif professional_id is not None:
        target = db.get(IsgProfessional, professional_id)
        if not target or target.osgb_id != oid:
            raise HTTPException(404, "Profesyonel bu OSGB’de bulunamadı.")
        filter_pid = professional_id

    if filter_pid is not None:
        pid = filter_pid
        for key in ("days", "overdue", "upcoming", "missing"):
            if key == "days":
                for day in data.get("days", []):
                    day["visits"] = [v for v in day.get("visits") or [] if v.get("professional_id") == pid]
                    day["visit_count"] = len(day["visits"])
                    day["planned_count"] = sum(1 for v in day["visits"] if v.get("status") == "planned")
                    day["completed_count"] = sum(1 for v in day["visits"] if v.get("status") == "completed")
            else:
                data[key] = [r for r in data.get(key) or [] if r.get("professional_id") == pid]
        # Özet KPI’leri filtrelenmiş güne göre yeniden hesapla
        visits_flat = [v for day in data.get("days") or [] for v in (day.get("visits") or [])]
        data["summary"] = {
            **(data.get("summary") or {}),
            "total_visits": len(visits_flat),
            "planned": sum(1 for v in visits_flat if v.get("status") == "planned"),
            "completed": sum(1 for v in visits_flat if v.get("status") == "completed"),
            "overdue": len(data.get("overdue") or []),
            "missing_coverage": len(data.get("missing") or []),
        }
        data["filter_professional_id"] = pid
    return data


@router.post("/visits/check-in", response_model=VisitResponse)
def check_in_visit(
    payload: VisitCheckStamp,
    db: Session = Depends(get_db),
    user: User = Depends(require_roles(*FIELD_VISIT_ROLES)),
):
    """İşyeri QR ile saha girişi — açık ziyaret oluşturur / süre sayacı başlar."""
    company = resolve_company_from_site_code(db, payload.site_verify_code)
    if not company:
        raise HTTPException(400, "QR kodu bu işyeri ile eşleşmiyor veya süresi dolmuş.")
    if not company.osgb_id:
        raise HTTPException(400, "İşyeri bir OSGB'ye bağlı değil.")
    ensure_company_access(db, user, company.id)
    pro = _require_field_assignment(db, user, company.id)
    open_visit = _open_checkin_visit(db, pro.id, company.id)
    if open_visit:
        raise HTTPException(409, "Bu işyerinde zaten açık bir girişiniz var. Önce çıkış yapın.")

    _verify_site_presence(db, company, payload.site_verify_code)
    now = datetime.utcnow()
    if user.role in _FIELD_ROLES and not user.osgb_id and pro.osgb_id:
        user.osgb_id = pro.osgb_id
    obj = ServiceVisit(
        osgb_id=company.osgb_id,
        company_id=company.id,
        professional_id=pro.id,
        visit_date=_today_tr(),
        start_time=_hhmm(now),
        end_time=None,
        duration_minutes=0,
        subject="Saha ziyareti (QR giriş)",
        notes=None,
        status=VisitStatus.PLANNED,
        checked_in_at=now,
        site_verified_at=now,
    )
    _apply_gps_stamp(obj, payload.gps_lat, payload.gps_lng, payload.gps_accuracy_m)
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj


@router.post("/visits/check-out", response_model=VisitResponse)
def check_out_visit(
    payload: VisitCheckStamp,
    db: Session = Depends(get_db),
    user: User = Depends(require_roles(*FIELD_VISIT_ROLES)),
):
    """İşyeri QR ile saha çıkışı — süre hesaplanır; defter/imza ayrı kalabilir."""
    company = resolve_company_from_site_code(db, payload.site_verify_code)
    if not company:
        raise HTTPException(400, "QR kodu bu işyeri ile eşleşmiyor veya süresi dolmuş.")
    ensure_company_access(db, user, company.id)
    pro = _require_field_assignment(db, user, company.id)
    obj = _open_checkin_visit(db, pro.id, company.id)
    if not obj:
        raise HTTPException(404, "Açık giriş bulunamadı. Önce QR ile giriş yapın.")

    _verify_site_presence(db, company, payload.site_verify_code)
    now = datetime.utcnow()
    if obj.checked_in_at and now < obj.checked_in_at:
        raise HTTPException(400, "Çıkış saati girişten önce olamaz.")
    obj.checked_out_at = now
    obj.end_time = _hhmm(now)
    if not obj.start_time and obj.checked_in_at:
        obj.start_time = _hhmm(obj.checked_in_at)
    delta = now - (obj.checked_in_at or now)
    obj.duration_minutes = max(0, int(delta.total_seconds() // 60))
    obj.site_verified_at = now
    obj.status = VisitStatus.COMPLETED
    _apply_gps_stamp(obj, payload.gps_lat, payload.gps_lng, payload.gps_accuracy_m)
    db.commit()
    db.refresh(obj)
    return obj


@router.post("/visits/plan", response_model=VisitResponse)
def plan_visit(
    payload: VisitPlanCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_roles(*ADMIN, *FIELD_VISIT_ROLES)),
):
    """Planlı ziyaret oluştur (defter zorunlu değil)."""
    scope(user, payload.osgb_id)
    ensure_company_access(db, user, payload.company_id)
    company = db.get(Company, payload.company_id)
    if not company or company.osgb_id != payload.osgb_id:
        raise HTTPException(400, "İşyeri OSGB ile eşleşmiyor.")
    professional = db.get(IsgProfessional, payload.professional_id)
    if not professional or professional.osgb_id != payload.osgb_id:
        raise HTTPException(400, "Profesyonel OSGB ile eşleşmiyor.")
    if user.role in _FIELD_ROLES:
        pro = find_professional_for_user(db, user)
        if not pro or pro.id != payload.professional_id:
            raise HTTPException(403, "Yalnız kendi adınıza planlı ziyaret oluşturabilirsiniz.")
    obj = ServiceVisit(
        osgb_id=payload.osgb_id,
        company_id=payload.company_id,
        professional_id=payload.professional_id,
        visit_date=payload.visit_date,
        start_time=payload.start_time,
        end_time=payload.end_time,
        duration_minutes=payload.duration_minutes,
        subject=payload.subject,
        notes=payload.notes,
        status=VisitStatus.PLANNED,
    )
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj


@router.get("/visits", response_model=list[VisitResponse])
def visits(osgb_id: int | None = None, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    # Saha personeli: yalnız kendi ziyaretleri
    if user.role in _FIELD_ROLES:
        pro = find_professional_for_user(db, user)
        if not pro:
            return []
        return list(
            db.scalars(
                select(ServiceVisit)
                .where(ServiceVisit.professional_id == pro.id)
                .order_by(ServiceVisit.visit_date.desc(), ServiceVisit.id.desc())
            ).all()
        )
    # EİSA veya OSGB yöneticisi: kendi OSGB kapsamındaki tüm ziyaretler
    if user.role not in (UserRole.GLOBAL_ADMIN, UserRole.COMPANY_ADMIN):
        raise HTTPException(403, "Ziyaret listesine erişim yetkiniz yok.")
    oid = active_osgb(user, osgb_id, db)
    return list(
        db.scalars(
            select(ServiceVisit)
            .where(ServiceVisit.osgb_id == oid)
            .order_by(ServiceVisit.visit_date.desc(), ServiceVisit.id.desc())
        ).all()
    )


@router.post("/visits", response_model=VisitResponse)
def create_visit(payload: VisitCreate, db: Session = Depends(get_db), user: User = Depends(require_roles(*FIELD_VISIT_ROLES))):
    company = db.get(Company, payload.company_id)
    if not company or not company.osgb_id:
        raise HTTPException(400, "İşyeri bir OSGB'ye bağlı değil.")
    ensure_company_access(db, user, payload.company_id)
    payload = payload.model_copy(update={"osgb_id": company.osgb_id})
    professional = _resolve_visit_professional(db, user, payload)
    data = payload.model_dump()
    data["professional_id"] = professional.id
    # Kullanıcı OSGB bağı boşsa profesyonelden senkronize et (liste/filtreler için)
    if user.role in _FIELD_ROLES and not user.osgb_id and professional.osgb_id:
        user.osgb_id = professional.osgb_id
    obj = ServiceVisit(**data)
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj


def _delete_notebook_file(
    obj: ServiceVisit,
    db: Session | None = None,
    user: User | None = None,
) -> None:
    if not obj.notebook_storage_path:
        return
    path = (_upload_root() / obj.notebook_storage_path).resolve()
    if _upload_root() in path.parents and path.exists():
        if db is not None:
            try:
                from app.services.archive_store import archive_file_before_delete

                archive_file_before_delete(
                    db,
                    source=path,
                    user=user,
                    company_id=obj.company_id,
                    osgb_id=obj.osgb_id,
                    entity_type="visit_notebook",
                    entity_id=str(obj.id),
                    original_name=obj.notebook_file_name,
                    notes="Ziyaret defteri silinmeden önce arşivlendi",
                )
            except Exception:
                logger.warning("visit notebook: archive-before-delete failed", exc_info=True)
        try:
            path.unlink()
        except OSError:
            pass


@router.patch("/visits/{visit_id}", response_model=VisitResponse)
def update_visit(
    visit_id: int,
    payload: VisitUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_roles(*FIELD_VISIT_ROLES, UserRole.GLOBAL_ADMIN, UserRole.COMPANY_ADMIN)),
):
    obj = _get_visit(db, visit_id, user)
    data = payload.model_dump(exclude_unset=True)
    if "company_id" in data and data["company_id"] is not None:
        company = db.get(Company, data["company_id"])
        if not company or not company.osgb_id:
            raise HTTPException(400, "İşyeri bir OSGB'ye bağlı değil.")
        ensure_company_access(db, user, data["company_id"])
        # Saha personeli yalnız kendi görevli olduğu işyerine taşıyabilir
        if user.role in _FIELD_ROLES:
            ensure_company_access(db, user, data["company_id"])
        obj.company_id = data["company_id"]
        obj.osgb_id = company.osgb_id
        data.pop("company_id", None)
    for key, value in data.items():
        setattr(obj, key, value)
    db.commit()
    db.refresh(obj)
    return obj


@router.delete("/visits/{visit_id}")
def delete_visit(
    visit_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(require_roles(*FIELD_VISIT_ROLES, UserRole.GLOBAL_ADMIN, UserRole.COMPANY_ADMIN)),
):
    obj = _get_visit(db, visit_id, user)
    _delete_notebook_file(obj, db=db, user=user)
    db.delete(obj)
    db.commit()
    return {"ok": True, "id": visit_id}


@router.post("/visits/{visit_id}/notebook", response_model=VisitResponse)
async def upload_visit_notebook(
    visit_id: int,
    file: UploadFile = File(...),
    gps_lat: float | None = Form(default=None),
    gps_lng: float | None = Form(default=None),
    gps_accuracy_m: float | None = Form(default=None),
    site_verify_code: str | None = Form(default=None),
    db: Session = Depends(get_db),
    user: User = Depends(require_roles(*FIELD_VISIT_ROLES, UserRole.GLOBAL_ADMIN, UserRole.COMPANY_ADMIN)),
):
    obj = _get_visit(db, visit_id, user)
    name = file.filename or "tespit-oneri-defteri.pdf"
    ext = Path(name).suffix.lower()
    if ext not in ALLOWED_NOTEBOOK:
        raise HTTPException(422, "Sadece pdf, jpg veya png yükleyin.")
    data = await file.read()
    if not data:
        raise HTTPException(400, "Boş dosya yüklenemez.")
    if len(data) > settings.max_upload_mb * 1024 * 1024:
        raise HTTPException(413, f"Dosya {settings.max_upload_mb} MB sınırını aşıyor.")
    if obj.notebook_storage_path:
        _delete_notebook_file(obj, db=db, user=user)
    rel = f"{obj.osgb_id}/visits/{obj.id}_{uuid4().hex[:10]}{ext}"
    if settings.upload_gateway_enabled:
        persist_relative(data, relative_path=rel, original_name=name)
    else:
        assert_safe_upload(data, ext, name)
        target = _upload_root() / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    obj.notebook_file_name = name
    obj.notebook_storage_path = rel.replace("\\", "/")
    obj.notebook_content_type = file.content_type or {
        ".pdf": "application/pdf",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".png": "image/png",
    }.get(ext, "application/octet-stream")
    _apply_gps_stamp(obj, gps_lat, gps_lng, gps_accuracy_m)
    # Giriş/çıkış QR ile zaten doğrulandıysa defter yüklemede yeniden QR isteme
    already_verified = bool(obj.site_verified_at) or bool(obj.checked_in_at)
    code_given = bool(site_verify_code and str(site_verify_code).strip())
    if already_verified and not code_given:
        pass
    else:
        _apply_site_verify(db, obj, db.get(Company, obj.company_id), site_verify_code)
    # Açık giriş varken yalnızca defter ekle; süreyi kapatma (çıkış ayrı)
    if obj.checked_in_at and not obj.checked_out_at:
        pass
    else:
        obj.status = VisitStatus.COMPLETED
    db.commit()
    db.refresh(obj)
    return obj


@router.get("/visits/{visit_id}/notebook")
def download_visit_notebook(
    visit_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    obj = _get_visit(db, visit_id, user)
    if not obj.notebook_storage_path:
        raise HTTPException(404, "Tespit öneri defteri dosyası yok.")
    from app.services.stored_files import response_for_storage_key

    return response_for_storage_key(
        obj.notebook_storage_path,
        filename=obj.notebook_file_name,
        media_type=obj.notebook_content_type or "application/octet-stream",
    )


@router.patch("/visits/{visit_id}/complete", response_model=VisitResponse)
def complete_visit(
    visit_id: int,
    payload: VisitGpsStamp | None = None,
    db: Session = Depends(get_db),
    user: User = Depends(require_roles(*FIELD_VISIT_ROLES)),
):
    obj = _get_visit(db, visit_id, user)
    stamp = payload or VisitGpsStamp()
    company = db.get(Company, obj.company_id)
    _apply_site_verify(db, obj, company, stamp.site_verify_code)
    _apply_gps_stamp(obj, stamp.gps_lat, stamp.gps_lng, stamp.gps_accuracy_m)
    _apply_signature(obj, stamp.signature_data_url)
    obj.status = VisitStatus.COMPLETED
    db.commit()
    db.refresh(obj)
    return obj


@router.get("/visits/{visit_id}/signature")
def download_visit_signature(
    visit_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    obj = _get_visit(db, visit_id, user)
    if not obj.signature_storage_path:
        raise HTTPException(404, "İmza dosyası yok.")
    from app.services.stored_files import response_for_storage_key

    suffix = Path(obj.signature_storage_path).suffix.lower()
    media = "image/png" if suffix == ".png" else "image/jpeg"
    return response_for_storage_key(
        obj.signature_storage_path,
        filename=obj.signature_file_name,
        media_type=media,
    )


@router.get("/leads", response_model=list[LeadResponse])
def leads(osgb_id: int | None = None, db: Session = Depends(get_db), user: User = Depends(require_roles(*ADMIN))):
    oid = active_osgb(user, osgb_id, db)
    return list(db.scalars(select(CrmLead).where(CrmLead.osgb_id == oid).order_by(CrmLead.created_at.desc())).all())

@router.post("/leads", response_model=LeadResponse)
def create_lead(payload: LeadCreate, db: Session = Depends(get_db), user: User = Depends(require_roles(*ADMIN))):
    scope(user, payload.osgb_id)
    obj = CrmLead(**payload.model_dump())
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj


def _get_lead(db: Session, lead_id: int, user: User) -> CrmLead:
    obj = db.get(CrmLead, lead_id)
    if not obj:
        raise HTTPException(404, "Fırsat bulunamadı.")
    scope(user, obj.osgb_id)
    return obj


@router.patch("/leads/{lead_id}", response_model=LeadResponse)
def update_lead(
    lead_id: int,
    payload: LeadUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_roles(*ADMIN)),
):
    obj = _get_lead(db, lead_id, user)
    data = payload.model_dump(exclude_unset=True)
    for key, value in data.items():
        setattr(obj, key, value)
    db.commit()
    db.refresh(obj)
    return obj


@router.post("/leads/{lead_id}/convert-to-contract")
def convert_lead(
    lead_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(require_roles(*ADMIN)),
):
    obj = _get_lead(db, lead_id, user)
    return convert_lead_to_contract(db, obj)


@router.get("/finance", response_model=list[FinanceResponse])
def finance(osgb_id: int | None = None, db: Session = Depends(get_db), user: User = Depends(require_roles(*ADMIN))):
    oid = active_osgb(user, osgb_id, db)
    return list(db.scalars(select(FinanceTransaction).where(FinanceTransaction.osgb_id == oid).order_by(FinanceTransaction.transaction_date.desc())).all())

@router.post("/finance", response_model=FinanceResponse)
def create_finance(payload: FinanceCreate, db: Session = Depends(get_db), user: User = Depends(require_roles(*ADMIN))):
    scope(user, payload.osgb_id)
    if payload.company_id:
        company = db.get(Company, payload.company_id)
        if not company or company.osgb_id != payload.osgb_id:
            raise HTTPException(400, "İşyeri OSGB ile eşleşmiyor.")
    obj = FinanceTransaction(**payload.model_dump())
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj


@router.patch("/finance/{finance_id}", response_model=FinanceResponse)
def update_finance(
    finance_id: int,
    payload: FinanceUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_roles(*ADMIN)),
):
    obj = db.get(FinanceTransaction, finance_id)
    if not obj:
        raise HTTPException(404, "Finans kaydı bulunamadı.")
    scope(user, obj.osgb_id)
    data = payload.model_dump(exclude_unset=True)
    for key, value in data.items():
        setattr(obj, key, value)
    db.commit()
    db.refresh(obj)
    return obj


@router.post("/finance/accrue-month")
def accrue_finance_month(
    osgb_id: int | None = None,
    db: Session = Depends(get_db),
    user: User = Depends(require_roles(*ADMIN)),
):
    """Aktif sözleşmeler için bu ayın tahakkuklarını oluştur (idempotent)."""
    oid = active_osgb(user, osgb_id, db)
    scope(user, oid)
    return accrue_month_for_osgb(db, oid)
